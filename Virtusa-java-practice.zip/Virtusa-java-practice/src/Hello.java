import java.util.*;
public class Hello {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("enter number: ");
        int a = sc.nextInt();
        System.out.println("entered number: "+a);
    }
}
