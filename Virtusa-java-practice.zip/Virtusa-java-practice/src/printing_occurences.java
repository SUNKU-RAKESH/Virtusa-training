import java.util.*;

import java.util.Scanner;

public class printing_occurences {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        Map <Character, Integer> map = new LinkedHashMap<>();
        char t[] = s.toCharArray();
        for(int i=0; i<t.length; i++){
             if(map.containsKey(t[i])){
                 map.put(t[i],map.get(t[i])+1);
             }
             else{
                 map.put(t[i],1);
             }
        }
        System.out.println(map);

    }

}
