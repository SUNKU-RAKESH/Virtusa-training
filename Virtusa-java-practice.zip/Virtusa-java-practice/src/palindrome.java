public class palindrome {
    public static void main(String[] args) {
        int a=454;
        int r,rev=0;
        int b=a;
        while(a!=0){
            r = a % 10;
            rev = rev * 10 + r;
            a=a/10;
        }
        if(b==rev){
            System.out.println("palindrome");
        }
        else{
            System.out.println("Not a palindrome");
        }
    }
}
