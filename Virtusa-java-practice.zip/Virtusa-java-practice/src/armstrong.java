import java.lang.Math;
public class armstrong {
    public static void main(String[] args) {
        int n=153;
        int a=n,b=n,count=0,re,sum=0;
        while(n!=0){
            n=n/10;
            count++;
        }
        while(a!=0){
            re = a%10;
            //sum = sum + (Math.pow(re,count));
            a=a/10;
        }
     if(sum == b){
         System.out.println("armstrong");
     }
     else{
         System.out.println("not armsrtong");
     }
    }
}
