public class stringpalindrome {
    public static void main(String[] args) {
        String a = "rakesh";
        String b= "hsekar";
        String c="";
        for(int i=a.length()-1; i>=0; i--){
            c = c + a.charAt(i);
        }
        System.out.println(c);
        if(c.equals(b)){
            System.out.println("Yes,it is a palindrome");
        }
        else{
            System.out.println("No, it is not a palindrome");
        }
    }
}
