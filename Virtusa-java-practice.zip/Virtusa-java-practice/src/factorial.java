public class factorial {
    public static void main(String[] args) {
        }
}
